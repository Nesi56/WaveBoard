from pathlib import Path

Path('web/index.html').write_text('''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#fbfaf7"><title>WaveBoard</title><link rel="icon" href="./assets/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="./styles.css"><script type="importmap">{"imports":{"three":"./vendor/three.module.js"}}</script><script type="module" src="./app.js"></script></head>
<body data-page="home"><main id="main" tabindex="-1"></main>
<button id="menu-toggle" class="menu-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="workspace-menu"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 9 7 7 7-7"/></svg></button>
<button id="menu-backdrop" class="menu-backdrop" aria-label="Close menu" tabindex="-1" hidden></button>
<section id="workspace-menu" class="workspace-menu" role="dialog" aria-label="Workspace menu" aria-modal="true" hidden><div class="menu-header"><button class="menu-home" data-page="home"><span data-icon="home"></span>Home</button><button id="menu-close" class="icon-button" aria-label="Close menu"><span data-icon="close"></span></button></div><div id="menu-tools" class="menu-grid"></div><div class="menu-footer"><button id="fullscreen-button" class="menu-tool"><span data-icon="expand"></span>Full screen</button><button id="help-button" class="menu-tool"><span data-icon="help"></span>Help</button><button id="settings-button" class="menu-tool"><span data-icon="settings"></span>Settings</button></div></section>
<dialog id="dialog"><div id="dialog-content"></div></dialog><div id="toast" role="status" aria-live="polite"></div><input type="file" id="local-file" hidden></body></html>''',encoding='utf-8')
path=Path('web/app.js')
s=path.read_text(encoding='utf-8')
s=s.replace('import { createWhiteboard } from "./whiteboard.js";', 'import { createWhiteboard } from "./whiteboard.js";\nimport { renderProjectorHome, renderProjectorBoard } from "./projector.js";')
def section(start,end,replacement):
    global s
    a,b=s.index(start),s.index(end)
    s=s[:a]+replacement.strip()+'\n'+s[b:]
section('function heading(', 'const button =','''
function heading(title,actions="") {return `<header class="utility-header"><h1>${title}</h1><div class="button-row">${actions}</div></header>`;}
''')
s=s.replace('function modal(title, body, actions = "") {','function modal(title, body, actions = "") {\n  closeMenu();')
section('function updateClock()', 'async function navigate(','''
let homeIndex=0;
function setMenu(html="") {$("#menu-tools").innerHTML=html;}
function closeMenu() {$("#workspace-menu").hidden=true;$("#menu-backdrop").hidden=true;$("#menu-toggle").setAttribute("aria-expanded","false");$("#main").inert=false;}
function openMenu() {$("#workspace-menu").hidden=false;$("#menu-backdrop").hidden=false;$("#menu-toggle").setAttribute("aria-expanded","true");$("#main").inert=true;$("#menu-close").focus();}
$("#menu-toggle").onclick=()=>$("#workspace-menu").hidden?openMenu():closeMenu();
$("#menu-close").onclick=()=>{closeMenu();$("#menu-toggle").focus();};
$("#menu-backdrop").onclick=closeMenu;
$("#workspace-menu").addEventListener("click",event=>{if(event.target.closest("button"))closeMenu();});
$("#workspace-menu").addEventListener("keydown",event=>{if(event.key!=="Tab")return;const buttons=$$("button:not(:disabled)",$("#workspace-menu")),first=buttons[0],last=buttons.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}});
$$("[data-icon]").forEach(el=>el.innerHTML=icon(el.dataset.icon));
document.addEventListener("click",event=>{const target=event.target.closest("[data-page]");if(target)navigate(target.dataset.page);});
$("#fullscreen-button").onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast("Use F11 for full screen.");}};
function renderHome(){state.cleanup=renderProjectorHome({main:$("#main"),icon,navigate,index:homeIndex,onIndexChange:index=>homeIndex=index});}
''')
s=s.replace('  ++state.navToken;\n','  closeMenu();\n  setMenu();\n  ++state.navToken;\n',1)
section('  $$("[data-page]").forEach','  try {\n    await {','''
  document.body.dataset.page=page;
  if(page!=="home")homeIndex=Math.max(0,pages.findIndex(p=>p.id===page)-1);
''')
section('function renderWhiteboard()','function downloadBlob(','''
function renderWhiteboard(){const surface=renderProjectorBoard({main:$("#main"),icon,createWhiteboard,setMenu,toast,downloadBlob});state.board=surface.board;state.cleanup=surface.dispose;}
''')
a=s.index('async function renderModels()');b=s.index('  $("#open-model").onclick',a)
s=s[:a]+'''async function renderModels(){
  const token=state.navToken;
  $("#main").innerHTML=`<section class="utility-screen">${heading("3D",button("open-model","Open","folder"))}<div class="viewer-wrap"><div id="viewer-host" class="viewer-host"></div><div class="viewer-label"><span id="model-name">Wave sculpture</span></div></div></section>`;
  setMenu(`${button("solid-mode","Solid","cube","menu-tool")}${button("wire-mode","Wireframe","grid","menu-tool")}${button("reset-model","Reset view","expand","menu-tool")}${button("auto-rotate","Rotate","rotate","menu-tool")}<p id="model-status" class="menu-note" role="status">Loading…</p>`);
'''+s[b:]
section('async function renderFiles()','function bindHold(','''
let fileQuery="";
async function renderFiles(){
  $("#main").innerHTML=`<section class="utility-screen">${heading("Files",button("choose-location","Location","folder"))}<div class="file-toolbar"><button class="icon-button" id="parent-folder" aria-label="Parent folder">${icon("back")}</button><span class="breadcrumb" id="file-path">Loading…</span></div><div class="file-content"><div id="file-list" class="file-list"><div class="empty-state"><div class="loading-dot"></div></div></div></section>`;
  setMenu(`${button("upload-file","Import","upload","menu-tool")}${button("find-file","Find file","file","menu-tool")}${button("refresh-files","Refresh","rotate","menu-tool")}`);
  $("#choose-location").onclick=async()=>{try{await refreshRoots();}catch(e){toast(e.message);return;}if(state.page!=="files")return;modal("Choose a location",`<div class="location-list">${state.roots.map(r=>`<button class="picker-entry" data-root="${escapeHTML(r.id)}">${icon(r.kind==="usb"?"usb":r.id==="demo"?"spark":"device")}<span>${escapeHTML(r.label)}</span></button>`).join("")}</div>`);$$("[data-root]").forEach(b=>b.onclick=()=>{state.root=b.dataset.root;state.path="";fileQuery="";$("#dialog").close();listFiles();});};
  $("#refresh-files").onclick=async()=>{try{await refreshRoots();if(state.page==="files")await listFiles();}catch(e){toast(e.message);}};
  $("#parent-folder").onclick=()=>{state.path=state.path.split("/").slice(0,-1).join("/");fileQuery="";listFiles();};
  $("#find-file").onclick=()=>{modal("Find a file",`<input class="search" id="file-search" placeholder="File name" aria-label="File name" value="${escapeHTML(fileQuery)}">`,button("apply-search","Find","file"));const apply=()=>{fileQuery=$("#file-search").value;$("#dialog").close();renderFileRows();};$("#apply-search").onclick=apply;$("#file-search").onkeydown=e=>{if(e.key==="Enter")apply();};$("#file-search").focus();};
  $("#upload-file").onclick=()=>{const root=state.root,path=state.path;chooseLocal("",async file=>{toast("Importing…");await api(`/api/upload?${new URLSearchParams({root,path,name:file.name})}`,{method:"POST",headers:{"Content-Type":"application/octet-stream"},body:file});toast("File imported.");if(state.page==="files")await listFiles();});};
  try{await refreshRoots();if(state.page==="files")await listFiles();}catch(e){if($("#file-list"))$("#file-list").innerHTML=`<div class="empty-state"><h2>Files unavailable</h2><p>${escapeHTML(e.message)}</p></div>`;}
}
let fileRequest=0;
async function listFiles(){const req=++fileRequest;try{const result=await api(`/api/files?${new URLSearchParams({root:state.root,path:state.path})}`);if(req!==fileRequest||state.page!=="files")return;state.entries=result.entries;$("#file-path").textContent=state.path||state.roots.find(r=>r.id===state.root)?.label||"Files";$("#parent-folder").disabled=!state.path;$("#upload-file").disabled=state.root==="demo";renderFileRows();}catch(e){if(req===fileRequest)toast(e.message);}}
function renderFileRows(){const entries=state.entries.filter(e=>e.name.toLowerCase().includes(fileQuery.toLowerCase()));$("#file-list").innerHTML=entries.length?entries.map((e,i)=>`<div class="file-row"><button class="file-open" data-file="${i}">${icon(fileIcon(e))}<span class="file-name">${escapeHTML(e.name)}</span></button><button class="file-details icon-button" data-details="${i}" aria-label="Details for ${escapeHTML(e.name)}">${icon("more")}</button></div>`).join(""):`<div class="empty-state">${icon("folder")}<h2>${fileQuery?"No matching files":"Empty folder"}</h2>${fileQuery?button("reset-search","Show all files","folder"):""}</div>`;if($("#reset-search"))$("#reset-search").onclick=()=>{fileQuery="";renderFileRows();};$$("[data-file]").forEach(b=>{const e=entries[Number(b.dataset.file)];b.onclick=()=>{if(e.is_dir){state.path=e.path;fileQuery="";listFiles();}else openEntry(state.root,e).catch(err=>toast(err.message));};bindHold(b,()=>showDetails(state.root,e));});$$("[data-details]").forEach(b=>b.onclick=()=>showDetails(state.root,entries[Number(b.dataset.details)]));}
''')
section('function renderVideo()','const demoSlides =','''
function renderVideo(){
  $("#main").innerHTML=`<section class="utility-screen">${heading("Video",button("open-video","Open","folder"))}<div class="media-stage" id="media-stage"><div class="empty-state">${icon("play")}<button class="button" id="video-empty-open">Open a video</button></div></div><div class="media-controls" id="video-controls" hidden><button class="icon-button" id="video-play" aria-label="Play">${icon("play")}</button><input id="video-seek" type="range" min="0" max="1000" value="0" aria-label="Video position"><span id="video-time">0:00</span><button class="icon-button" id="video-fullscreen" aria-label="Full screen video">${icon("expand")}</button></div></section>`;
  setMenu(`${button("mute-video","Mute","play","menu-tool")}<p class="menu-note" id="video-info">Open an MP4 or WebM.</p>`);
  const pick=()=>pickFile("Open a video",["mp4","webm","ogv","mov","m4v","mkv"],(root,entry)=>{remember(root,entry);setVideo(fileURL(root,entry.path),entry.name);},file=>setVideo(URL.createObjectURL(file),file.name));$("#open-video").onclick=pick;$("#video-empty-open").onclick=pick;$("#mute-video").disabled=true;
}
const mediaTime=seconds=>`${Math.floor(seconds/60)}:${String(Math.floor(seconds%60)).padStart(2,"0")}`;
function setVideo(url,name){
  const stage=$("#media-stage");if(!stage){if(url.startsWith("blob:"))URL.revokeObjectURL(url);return;}
  const previous=$("video",stage);if(previous){previous.pause();previous.removeAttribute("src");previous.load();}
  if(state.videoURL&&state.videoURL!==url)URL.revokeObjectURL(state.videoURL);state.videoURL=url.startsWith("blob:")?url:null;
  stage.innerHTML='<video playsinline preload="metadata" aria-label="Video player"></video>';
  const video=$("video",stage);video.src=url;$("#video-controls").hidden=false;$("#video-info").textContent=name;$("#mute-video").disabled=false;$("#mute-video").textContent="Mute";
  const sync=()=>{if(!video.isConnected)return;const playing=!video.paused&&!video.ended;$("#video-play").innerHTML=playing?'<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6 4h4v16H6zM14 4h4v16h-4z"/></svg>':icon("play");$("#video-play").setAttribute("aria-label",playing?"Pause":"Play");$("#video-time").textContent=mediaTime(video.currentTime);$("#video-seek").disabled=!Number.isFinite(video.duration);$("#video-seek").value=Number.isFinite(video.duration)?String(video.currentTime/video.duration*1000):"0";};
  for(const event of ["loadedmetadata","timeupdate","play","pause","ended"])video.addEventListener(event,sync);
  $("#video-play").onclick=()=>video.paused?video.play().catch(()=>toast("This video could not play.")):video.pause();
  $("#video-seek").oninput=e=>{if(Number.isFinite(video.duration))video.currentTime=Number(e.target.value)/1000*video.duration;};
  $("#mute-video").onclick=()=>{video.muted=!video.muted;$("#mute-video").textContent=video.muted?"Unmute":"Mute";};
  $("#video-fullscreen").onclick=async()=>{try{video.controls=true;await video.requestFullscreen();}catch{video.controls=false;toast("Use the menu for full screen.");}};
  const onFullscreen=()=>{video.controls=document.fullscreenElement===video;};document.addEventListener("fullscreenchange",onFullscreen);state.cleanup?.();state.cleanup=()=>document.removeEventListener("fullscreenchange",onFullscreen);
  video.onerror=()=>{if(!video.isConnected)return;toast("Cannot play this video. Try MP4 or WebM.");$("#video-info").textContent="Unsupported format or disconnected drive.";};sync();
}
''')
section('const demoSlides =','function renderSlides()', '''
const demoSlides=[{title:"WaveBoard",copy:"Your ideas, in reach."},{title:"Tap. Draw. Explore.",copy:"Five tools. One board."},{title:"Make it yours.",copy:"Open a presentation to begin."}];
''')
a=s.index('  $("#main").innerHTML',s.index('function renderSlides()'));b=s.index('  showSlide();',a)
s=s[:a]+'''  $("#main").innerHTML=`<section class="utility-screen">${heading("Slides",button("open-slides","Open","folder"))}<div class="slide-stage" id="slide-stage"></div><div class="slide-controls"><button class="icon-button" id="prev-slide" aria-label="Previous slide">${icon("left")}</button><span class="slide-counter" id="slide-counter"></span><button class="icon-button" id="next-slide" aria-label="Next slide">${icon("right")}</button></div></section>`;
  setMenu(`${button("present-slides","Present","expand","menu-tool")}<p id="slide-note" class="menu-note">Sample slides</p>`);
'''+s[b:]
s=s.replace('<div class="eyebrow">${s.eyebrow}</div>','').replace('Getting your slides ready…','Loading slides…').replace('<p>This may take a moment for a larger presentation.</p>','').replace('One more thing to set up.','Cannot open slides').replace('"Choose from this computer"','"Import a file"').replace('"Open a presentation"','"Open slides"')
s=s.replace('document.addEventListener("keydown", (event) => {\n  if (','document.addEventListener("keydown", (event) => {\n  if(event.key === "Escape" && !$("#workspace-menu").hidden){closeMenu();$("#menu-toggle").focus();return;}\n  if (!$("#workspace-menu").hidden) return;\n  if (')
section('$("#help-button").onclick','// Input adapter','''
$("#help-button").onclick=()=>modal("Simple by design",`<div class="dialog-copy"><p><strong>Home:</strong> Use the arrows. Tap a card to open it.</p><p><strong>Draw:</strong> Pick a color and dot size on the left. Drag to draw.</p><p><strong>Top tab:</strong> Open tools, save, or go Home.</p><p><strong>Files:</strong> Tap to open. Hold for details.</p><p><strong>3D:</strong> Drag to rotate. Pinch to zoom.</p></div>`);
$("#settings-button").onclick=async()=>{try{await refreshRoots();}catch{}const presentation=state.status?.presentation;modal("Settings",`<label class="settings-row"><span>Extra contrast</span><input type="checkbox" id="contrast-setting" ${document.body.classList.contains("high-contrast")?"checked":""}></label><div class="settings-row"><span>PowerPoint</span><span class="status-badge">${presentation?.available?"Ready":"Setup needed"}</span></div>${presentation?.available?"":'<p class="dialog-copy">On Ubuntu, install LibreOffice Impress and poppler-utils.</p>'}`);$("#contrast-setting").onchange=e=>{document.body.classList.toggle("high-contrast",e.target.checked);try{localStorage.setItem("waveboard-contrast",String(e.target.checked));}catch{}};};
try{document.body.classList.toggle("high-contrast",localStorage.getItem("waveboard-contrast")==="true");}catch{}

''')
s=s.replace('    $("#connection-label").textContent = "Server unavailable";','    toast("The local server is unavailable.");')
path.write_text(s,encoding='utf-8')
