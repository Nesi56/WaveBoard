from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor

target = Path(__file__).resolve().parents[1] / 'web/assets/demo/welcome.pdf'
c = canvas.Canvas(str(target), pagesize=(1280, 720), invariant=1)
c.setTitle('Welcome to WaveBoard')
c.setAuthor('WaveBoard')
bg, ink, green, muted = '#F7F8F3', '#25352E', '#BDCFAB', '#66756C'

def base(number, label):
    c.setFillColor(HexColor(bg)); c.rect(0, 0, 1280, 720, fill=1, stroke=0)
    c.setFillColor(HexColor(ink)); c.setFont('Helvetica-Bold', 20); c.drawString(70, 650, 'WaveBoard')
    c.setFont('Helvetica', 14); c.setFillColor(HexColor(muted)); c.drawRightString(1210, 650, label)
    c.setStrokeColor(HexColor('#DBE2D7')); c.line(70, 610, 1210, 610)
    c.setFont('Helvetica', 13); c.drawString(70, 48, 'Original sample presentation  /  Tap next to continue')
    c.drawRightString(1210, 48, str(number).zfill(2))

base(1, 'YOUR IDEAS, IN REACH')
c.setFillColor(HexColor(ink)); c.setFont('Helvetica-Bold', 66); c.drawString(70, 465, 'A little space.')
c.drawString(70, 385, 'A lot of possibility.')
c.setFont('Helvetica', 24); c.setFillColor(HexColor(muted)); c.drawString(74, 294, 'Draw, explore, and share on the big screen.')
c.setFillColor(HexColor(green)); c.circle(1020, 376, 148, fill=1, stroke=0)
c.setStrokeColor(HexColor(ink)); c.setLineWidth(4)
for offset in range(-2, 3):
    path = c.beginPath(); path.moveTo(900, 370 + offset * 26)
    path.curveTo(954, 460 + offset * 26, 1058, 280 + offset * 26, 1140, 390 + offset * 26)
    c.drawPath(path)
c.showPage()
base(2, 'FIVE TOOLS. ONE BOARD.')
c.setFillColor(HexColor(ink)); c.setFont('Helvetica-Bold', 49); c.drawString(70, 500, 'Make room for your next idea.')
items = [('01', '3D space', 'Explore a model from every angle.'), ('02', 'Whiteboard', 'Sketch, annotate, and start again.'), ('03', 'Files', 'Open work from this device or a USB.'), ('04', 'Video', 'Play a clip. Pause on the big moment.'), ('05', 'Presentations', 'Move through a story, one slide at a time.')]
for index, (number, title, subtitle) in enumerate(items):
    y = 405 - index * 60
    c.setFillColor(HexColor(green)); c.roundRect(70, y - 9, 42, 32, 9, fill=1, stroke=0)
    c.setFillColor(HexColor(ink)); c.setFont('Helvetica-Bold', 14); c.drawCentredString(91, y + 1, number)
    c.setFont('Helvetica-Bold', 20); c.drawString(136, y, title)
    c.setFont('Helvetica', 19); c.setFillColor(HexColor(muted)); c.drawString(390, y, subtitle)
c.showPage(); c.save()
print(target)
