const { chromium } = require('C:/Users/kikel/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs = require('node:fs');
const path = require('node:path');
(async () => {
  const browser = await chromium.launch({ executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', headless: true });
  try {
    const page = await browser.newPage({viewport:{width:960,height:540}});
    const bytes = await page.evaluate(async () => {
      const canvas = document.createElement('canvas'); canvas.width=960; canvas.height=540;
      const ctx = canvas.getContext('2d');
      const stream = canvas.captureStream(30);
      const recorder = new MediaRecorder(stream, {mimeType:'video/webm;codecs=vp8', videoBitsPerSecond:1400000});
      const chunks = [];
      const done = new Promise(resolve => { recorder.ondataavailable=e=>chunks.push(e.data); recorder.onstop=async()=>resolve(Array.from(new Uint8Array(await new Blob(chunks,{type:'video/webm'}).arrayBuffer()))); });
      const draw = frame => {
        const t = frame/150;
        ctx.fillStyle='#14291f'; ctx.fillRect(0,0,960,540);
        ctx.fillStyle='#cee2b9'; ctx.beginPath(); ctx.arc(705,260,135,0,Math.PI*2); ctx.fill();
        ctx.strokeStyle='#557a53'; ctx.lineWidth=3;
        for(let row=-3;row<=3;row++) {
          ctx.beginPath();
          for(let x=0;x<=360;x+=4) {
            const y=260+row*24+35*Math.sin(x/63+t*Math.PI*2);
            x?ctx.lineTo(520+x,y):ctx.moveTo(520+x,y);
          }
          ctx.stroke();
        }
        ctx.fillStyle='#eff5e8'; ctx.font='bold 24px Arial'; ctx.fillText('WaveBoard',58,67);
        ctx.font='bold 60px Arial'; ctx.fillText('Ideas in',58,222); ctx.fillText('motion.',58,294);
        ctx.fillStyle='#b3c7b6'; ctx.font='20px Arial'; ctx.fillText('An original sample clip',61,346);
        ctx.fillStyle='#37513f'; ctx.fillRect(58,469,844,4); ctx.fillStyle='#c8dcb5'; ctx.fillRect(58,469,844*t,4);
        ctx.font='14px Arial'; ctx.fillText('TAP TO PAUSE  /  DRAG TO SEEK',58,508);
      };
      draw(0); recorder.start();
      for(let frame=0;frame<150;frame++) {draw(frame); await new Promise(resolve=>setTimeout(resolve,1000/30));}
      recorder.stop(); stream.getTracks().forEach(track=>track.stop());
      return done;
    });
    const target=path.resolve(__dirname,'../web/assets/demo/waveboard-demo.webm');
    fs.writeFileSync(target,Buffer.from(bytes)); console.log(target+' ('+bytes.length+' bytes)');
  } finally { await browser.close(); }
})().catch(error=>{console.error(error);process.exitCode=1});
