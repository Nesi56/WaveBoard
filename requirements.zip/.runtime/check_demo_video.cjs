const { chromium } = require('C:/Users/kikel/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const browser=await chromium.launch({executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});
 try {
  const page=await browser.newPage();
  await page.goto('http://127.0.0.1:8765/');
  console.log(await page.evaluate(async()=>{
   const video=document.createElement('video');video.muted=true;video.src='/api/file?root=demo&path=waveboard-demo.webm';document.body.appendChild(video);
   await new Promise((resolve,reject)=>{video.onloadedmetadata=resolve;video.onerror=()=>reject(new Error(video.error?.message));setTimeout(()=>reject(new Error('timeout')),8000)});
   const initial=String(video.duration);await video.play();await new Promise(resolve=>setTimeout(resolve,300));
   const playing=video.currentTime>0;video.currentTime=2.0;
   await new Promise(resolve=>setTimeout(resolve,500));const currentTime=video.currentTime;video.pause();
   return {initialDuration:initial,playing,currentTime,videoWidth:video.videoWidth,videoHeight:video.videoHeight};
  }));
 } finally {await browser.close()}
})().catch(error=>{console.error(error);process.exitCode=1});
